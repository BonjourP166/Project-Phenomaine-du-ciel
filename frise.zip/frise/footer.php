<footer class="site-footer">
  <div class="footer-links">
    <img src="images/logo.jpg" alt="Logo" class="cercle2"> 
    <a href="a_propos_de_nous.php">À propos</a>
    <a href="contact.php">Nous contacter</a>
  </div>
  <p>© 2025 Univers en Direct — Données : NASA et IMO</p>
</footer>