<header class="site-header">
  <div class="logo">
    <img src="images/logo.jpg" alt="Logo" class="cercle1"> 
    <a href="index.php" class="a_h2">Univers en direct</a>
  </div>

  <nav class="header">
    <a href="pages/phenomene.php">Phenomene</a>
    <a href="pages/carte.php">Carte</a>
    <a href="pages/frise.php">Frise</a>
    <a href="pages/forum.php">Forum</a>
    <a href="pages/curiosite.php">Curiosite</a>
    <a href="pages/quizz.php">Quizz</a>
    <img src="images/profile.png" alt="Logo" class="cercle3">
    <a href="login_system/formulaire_connextions.php">connexion</a>
    <a href="pages/profile.php">Profile</a>
  </nav>
  
</header>